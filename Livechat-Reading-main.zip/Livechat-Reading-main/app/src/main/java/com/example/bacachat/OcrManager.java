package com.example.bacachat;

import android.graphics.Bitmap;
import android.graphics.Rect;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.List;

public class OcrManager {

    public interface Callback {
        void onText(String text);
        void onError(Exception error);
    }

    public static class OcrLine {

        private final String text;
        private final Rect boundingBox;

        public OcrLine(
                String text,
                Rect boundingBox
        ) {

            this.text = text;
            this.boundingBox =
                    new Rect(boundingBox);
        }

        public String getText() {
            return text;
        }

        public Rect getBoundingBox() {
            return new Rect(
                    boundingBox
            );
        }
    }

    public interface LineCallback {

        void onLines(
                List<OcrLine> lines
        );

        void onError(
                Exception error
        );
    }

    private final TextRecognizer recognizer;

    public OcrManager() {

        recognizer =
                TextRecognition.getClient(
                        TextRecognizerOptions
                                .DEFAULT_OPTIONS
                );
    }

    public void recognize(
            Bitmap bitmap,
            Callback callback
    ) {

        if (bitmap == null) {

            callback.onError(
                    new IllegalArgumentException(
                            "Bitmap tidak tersedia"
                    )
            );

            return;
        }

        InputImage image =
                InputImage.fromBitmap(
                        bitmap,
                        0
                );

        Task<Text> task =
                recognizer.process(image);

        task.addOnSuccessListener(
                result -> {

                    String text =
                            result.getText();

                    callback.onText(
                            text == null
                                    ? ""
                                    : text.trim()
                    );
                }
        );

        task.addOnFailureListener(
                callback::onError
        );
    }

    public void recognizeLines(
            Bitmap bitmap,
            LineCallback callback
    ) {

        if (bitmap == null) {

            callback.onError(
                    new IllegalArgumentException(
                            "Bitmap tidak tersedia"
                    )
            );

            return;
        }

        InputImage image =
                InputImage.fromBitmap(
                        bitmap,
                        0
                );

        recognizer
                .process(image)
                .addOnSuccessListener(
                        result -> {

                            List<OcrLine> lines =
                                    new ArrayList<>();

                            for (
                                    Text.TextBlock block :
                                    result.getTextBlocks()
                            ) {

                                for (
                                        Text.Line line :
                                        block.getLines()
                                ) {

                                    String text =
                                            line.getText();

                                    Rect box =
                                            line.getBoundingBox();

                                    if (text == null ||
                                            text.trim().isEmpty() ||
                                            box == null) {

                                        continue;
                                    }

                                    lines.add(
                                            new OcrLine(
                                                    text.trim(),
                                                    box
                                            )
                                    );
                                }
                            }

                            callback.onLines(
                                    lines
                            );
                        }
                )
                .addOnFailureListener(
                        callback::onError
                );
    }

    public void close() {

        recognizer.close();
    }
}

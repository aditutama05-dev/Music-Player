package com.example.bacachat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

public class FloatingService extends Service {

    public static final String EXTRA_SCREEN_CAPTURE_RESULT =
            "SCREEN_CAPTURE_RESULT";

    public static final String EXTRA_SCREEN_CAPTURE_DATA =
            "SCREEN_CAPTURE_DATA";

    private static final String CHANNEL_ID =
            "live_chat_reader_channel";

    private WindowManager windowManager;

    private TextView floatingButton;

    private FloatingReader floatingReader;

    private WindowManager.LayoutParams buttonParams;

    private float downX;
    private float downY;

    private int startX;
    private int startY;

    private boolean moving = false;

    private MediaProjection mediaProjection;

    @Override
    public void onCreate() {
        super.onCreate();

        createNotificationChannel();

        startForeground(
                1,
                createNotification()
        );

        windowManager =
                (WindowManager)
                        getSystemService(
                                WINDOW_SERVICE
                        );

        floatingReader =
                new FloatingReader(this);

        createFloatingButton();
    }

    @Override
    public int onStartCommand(
            Intent intent,
            int flags,
            int startId
    ) {

        if (intent != null) {

            int screenCaptureResultCode = intent.getIntExtra(
                            EXTRA_SCREEN_CAPTURE_RESULT,
                            -1
                    );

            Intent screenCaptureData;
            if (Build.VERSION.SDK_INT >= 33) {

                screenCaptureData =
                        intent.getParcelableExtra(
                                EXTRA_SCREEN_CAPTURE_DATA,
                                Intent.class
                        );

            } else {

                screenCaptureData =
                        intent.getParcelableExtra(
                                EXTRA_SCREEN_CAPTURE_DATA
                        );
            }

            if (
                    floatingReader != null &&
                    screenCaptureResultCode == android.app.Activity.RESULT_OK &&
                    screenCaptureData != null
            ) {
                createMediaProjection(screenCaptureResultCode, screenCaptureData);
            }
        }

        return START_NOT_STICKY;
    }

    private void createMediaProjection(int resultCode, Intent data) {
        if (mediaProjection != null) {
            // A running service must keep using its original consent token. A new
            // activation creates a fresh service after the old one has been stopped.
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (manager == null) {
            return;
        }
        try {
            mediaProjection = manager.getMediaProjection(resultCode, data);
            if (mediaProjection != null && floatingReader != null) {
                floatingReader.setMediaProjection(mediaProjection);
            }
        } catch (SecurityException error) {
            stopSelf();
        }
    }

    private void createNotificationChannel() {

        if (Build.VERSION.SDK_INT >= 26) {

            NotificationChannel channel =
                    new NotificationChannel(
                            CHANNEL_ID,
                            "Live Chat Reader",
                            NotificationManager
                                    .IMPORTANCE_LOW
                    );

            NotificationManager manager =
                    (NotificationManager)
                            getSystemService(
                                    NOTIFICATION_SERVICE
                            );

            if (manager != null) {

                manager.createNotificationChannel(
                        channel
                );
            }
        }
    }

    private Notification createNotification() {

        return new NotificationCompat.Builder(
                this,
                CHANNEL_ID
        )
                .setContentTitle(
                        "Live Chat Reader"
                )
                .setContentText(
                        "Floating Button aktif"
                )
                .setSmallIcon(
                        android.R.drawable.ic_menu_view
                )
                .setOngoing(true)
                .build();
    }

    private void createFloatingButton() {

        floatingButton =
                new TextView(this);

        floatingButton.setText("●");

        floatingButton.setTextColor(
                Color.WHITE
        );

        floatingButton.setTextSize(24);

        floatingButton.setGravity(
                Gravity.CENTER
        );

        /*
         * Birikan warna biru supaya lebih mudah
         * terlihat daripada hitam.
         */
        floatingButton.setBackgroundColor(
                Color.rgb(
                        0,
                        140,
                        255
                )
        );

        int size =
                (int) (
                        56 *
                                getResources()
                                        .getDisplayMetrics()
                                        .density
                );

        int windowType;

        if (
                Build.VERSION.SDK_INT >=
                        Build.VERSION_CODES.O
        ) {

            windowType =
                    WindowManager.LayoutParams
                            .TYPE_APPLICATION_OVERLAY;

        } else {

            windowType =
                    WindowManager.LayoutParams
                            .TYPE_PHONE;
        }

        buttonParams =
                new WindowManager.LayoutParams(
                        size,
                        size,
                        windowType,
                        WindowManager.LayoutParams
                                .FLAG_NOT_FOCUSABLE,
                        PixelFormat.TRANSLUCENT
                );

        buttonParams.gravity =
                Gravity.TOP |
                        Gravity.START;

        buttonParams.x = 20;
        buttonParams.y = 200;

        try {

            windowManager.addView(
                    floatingButton,
                    buttonParams
            );

        } catch (Exception error) {

            stopSelf();

            return;
        }

        floatingButton.setOnTouchListener(
                (view, event) -> {

                    switch (
                            event.getActionMasked()
                    ) {

                        case MotionEvent.ACTION_DOWN:

                            downX =
                                    event.getRawX();

                            downY =
                                    event.getRawY();

                            startX =
                                    buttonParams.x;

                            startY =
                                    buttonParams.y;

                            moving = false;

                            return true;

                        case MotionEvent.ACTION_MOVE:

                            float dx =
                                    event.getRawX()
                                            - downX;

                            float dy =
                                    event.getRawY()
                                            - downY;

                            if (
                                    Math.abs(dx) > 8 ||
                                    Math.abs(dy) > 8
                            ) {

                                moving = true;
                            }

                            buttonParams.x =
                                    startX +
                                            (int) dx;

                            buttonParams.y =
                                    startY +
                                            (int) dy;

                            try {

                                windowManager
                                        .updateViewLayout(
                                                floatingButton,
                                                buttonParams
                                        );

                            } catch (Exception ignored) {
                            }

                            return true;

                        case MotionEvent.ACTION_UP:

                            if (moving) {

                                snapFloatingButton();

                            } else {

                                if (
                                        floatingReader != null
                                ) {

                                    floatingReader
                                            .startSelection();
                                }
                            }

                            return true;

                        default:

                            return true;
                    }
                }
        );
    }

    private void snapFloatingButton() {

        if (
                floatingButton == null ||
                buttonParams == null
        ) {

            return;
        }

        int screenWidth =
                getResources()
                        .getDisplayMetrics()
                        .widthPixels;

        int buttonWidth =
                floatingButton.getWidth();

        if (
                buttonParams.x <
                        screenWidth / 2
        ) {

            buttonParams.x = 0;

        } else {

            buttonParams.x =
                    screenWidth -
                            buttonWidth;
        }

        if (buttonParams.x < 0) {

            buttonParams.x = 0;
        }

        if (buttonParams.y < 0) {

            buttonParams.y = 0;
        }

        int screenHeight =
                getResources()
                        .getDisplayMetrics()
                        .heightPixels;

        int buttonHeight =
                floatingButton.getHeight();

        int maxY =
                screenHeight -
                        buttonHeight;

        if (maxY < 0) {

            maxY = 0;
        }

        if (
                buttonParams.y >
                        maxY
        ) {

            buttonParams.y = maxY;
        }

        try {

            windowManager.updateViewLayout(
                    floatingButton,
                    buttonParams
            );

        } catch (Exception ignored) {
        }
    }

    private void vibrate() {

        Vibrator vibrator =
                (Vibrator)
                        getSystemService(
                                VIBRATOR_SERVICE
                        );

        if (vibrator == null) {
            return;
        }

        if (Build.VERSION.SDK_INT >= 26) {

            vibrator.vibrate(
                    VibrationEffect.createOneShot(
                            80,
                            180
                    )
            );

        } else {

            vibrator.vibrate(80);
        }
    }

    @Override
    public void onDestroy() {

        if (floatingReader != null) {

            floatingReader.close();

            floatingReader = null;
        }

        mediaProjection = null;

        if (floatingButton != null) {

            try {

                windowManager.removeView(
                        floatingButton
                );

            } catch (Exception ignored) {
            }

            floatingButton = null;
        }

        super.onDestroy();
    }

    @Override
    public IBinder onBind(
            Intent intent
    ) {

        return null;
    }
                }

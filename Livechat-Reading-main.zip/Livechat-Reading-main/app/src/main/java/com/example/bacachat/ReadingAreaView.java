package com.example.bacachat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

public class ReadingAreaView extends View {

    public interface AreaListener {
        void onAreaSelected(RectF area);
    }

    private final Paint borderPaint = new Paint();
    private final Paint shadePaint = new Paint();

    private AreaListener listener;

    private boolean selecting = false;

    private float startX;
    private float startY;

    private final RectF selectedArea =
            new RectF();

    public ReadingAreaView(Context context) {
        super(context);

        setBackgroundColor(
                Color.TRANSPARENT
        );

        borderPaint.setStyle(
                Paint.Style.STROKE
        );

        borderPaint.setStrokeWidth(
                dp(3)
        );

        borderPaint.setColor(
                Color.rgb(70, 255, 120)
        );

        borderPaint.setAntiAlias(true);

        shadePaint.setStyle(
                Paint.Style.FILL
        );

        shadePaint.setColor(
                Color.argb(
                        55,
                        0,
                        0,
                        0
                )
        );
    }

    private float dp(float value) {

        return value *
                getResources()
                        .getDisplayMetrics()
                        .density;
    }

    public void setAreaListener(
            AreaListener listener
    ) {

        this.listener = listener;
    }

    @Override
    public boolean onTouchEvent(
            MotionEvent event
    ) {

        float x = event.getX();
        float y = event.getY();

        switch (event.getActionMasked()) {

            case MotionEvent.ACTION_DOWN:

                startX = x;
                startY = y;

                selectedArea.set(
                        x,
                        y,
                        x,
                        y
                );

                selecting = true;

                invalidate();

                return true;

            case MotionEvent.ACTION_MOVE:

                if (!selecting) {
                    return true;
                }

                selectedArea.set(
                        Math.min(startX, x),
                        Math.min(startY, y),
                        Math.max(startX, x),
                        Math.max(startY, y)
                );

                invalidate();

                return true;

            case MotionEvent.ACTION_UP:

                if (!selecting) {
                    return true;
                }

                selectedArea.set(
                        Math.min(startX, x),
                        Math.min(startY, y),
                        Math.max(startX, x),
                        Math.max(startY, y)
                );

                selecting = false;

                if (selectedArea.width() >= dp(30) &&
                        selectedArea.height() >= dp(30)) {

                    if (listener != null) {

                        listener.onAreaSelected(
                                new RectF(
                                        selectedArea
                                )
                        );
                    }
                }

                selectedArea.setEmpty();

                invalidate();

                return true;

            case MotionEvent.ACTION_CANCEL:

                selecting = false;

                selectedArea.setEmpty();

                invalidate();

                return true;
        }

        return true;
    }

    @Override
    protected void onDraw(
            Canvas canvas
    ) {

        super.onDraw(canvas);

        if (!selecting ||
                selectedArea.isEmpty()) {

            return;
        }

        canvas.drawRect(
                0,
                0,
                getWidth(),
                selectedArea.top,
                shadePaint
        );

        canvas.drawRect(
                0,
                selectedArea.top,
                selectedArea.left,
                selectedArea.bottom,
                shadePaint
        );

        canvas.drawRect(
                selectedArea.right,
                selectedArea.top,
                getWidth(),
                selectedArea.bottom,
                shadePaint
        );

        canvas.drawRect(
                0,
                selectedArea.bottom,
                getWidth(),
                getHeight(),
                shadePaint
        );

        canvas.drawRect(
                selectedArea,
                borderPaint
        );
    }
            }

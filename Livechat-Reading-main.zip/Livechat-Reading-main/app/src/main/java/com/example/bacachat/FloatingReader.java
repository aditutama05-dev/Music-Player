package com.example.bacachat;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Toast;

/** Coordinates the selection overlay, one-shot capture, OCR, and speech. */
public class FloatingReader {
    private final Context context;
    private final WindowManager windowManager;
    private final OcrManager ocr;
    private final TtsManager tts;
    private final ScreenCaptureManager screenCapture;

    private ReadingAreaView readingAreaView;
    private boolean selectionMode;
    private boolean closed;

    public FloatingReader(Context context) {
        this.context = context.getApplicationContext();
        windowManager = (WindowManager) this.context.getSystemService(Context.WINDOW_SERVICE);
        ocr = new OcrManager();
        tts = new TtsManager(this.context);
        screenCapture = new ScreenCaptureManager(this.context);
    }

    public void setMediaProjection(android.media.projection.MediaProjection projection) {
        screenCapture.setMediaProjection(projection);
    }

    public void startSelection() {
        if (closed || selectionMode) {
            return;
        }
        if (!screenCapture.isReady()) {
            Toast.makeText(context, "Izin tangkap layar tidak tersedia. Aktifkan ulang Live Chat Reader.", Toast.LENGTH_LONG).show();
            return;
        }

        selectionMode = true;
        readingAreaView = new ReadingAreaView(context);
        readingAreaView.setAreaListener(area -> {
            if (area == null) {
                closeSelection();
                return;
            }

            // The overlay occupies the display, so retain its measured size for scaling
            // the user selection into the bitmap returned by MediaProjection.
            int overlayWidth = readingAreaView.getWidth();
            int overlayHeight = readingAreaView.getHeight();
            closeSelection();
            vibrate();
            // Give WindowManager one traversal to remove the green overlay before
            // MediaProjection obtains its first frame.
            new Handler(Looper.getMainLooper()).postDelayed(
                    () -> captureScreen(area, overlayWidth, overlayHeight), 100);
        });

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;

        try {
            windowManager.addView(readingAreaView, params);
            vibrate();
        } catch (Exception error) {
            selectionMode = false;
            readingAreaView = null;
            Toast.makeText(context, "Gagal membuka area seleksi", Toast.LENGTH_SHORT).show();
        }
    }

    private void captureScreen(RectF selection, int overlayWidth, int overlayHeight) {
        Toast.makeText(context, "Mengambil layar...", Toast.LENGTH_SHORT).show();
        screenCapture.start(new ScreenCaptureManager.Callback() {
            @Override
            public void onFrame(Bitmap bitmap) {
                Bitmap selectedBitmap = cropToSelection(bitmap, selection, overlayWidth, overlayHeight);
                recycle(bitmap);
                if (selectedBitmap == null) {
                    screenCapture.stop();
                    Toast.makeText(context, "Area yang dipilih tidak valid", Toast.LENGTH_SHORT).show();
                    return;
                }
                recognizeSelectedArea(selectedBitmap);
            }

            @Override
            public void onError(Exception error) {
                screenCapture.stop();
                Toast.makeText(context, "Screen Capture error: " + errorMessage(error), Toast.LENGTH_LONG).show();
            }
        });
    }

    private Bitmap cropToSelection(Bitmap screenshot, RectF selection, int overlayWidth, int overlayHeight) {
        if (screenshot == null || screenshot.isRecycled() || overlayWidth <= 0 || overlayHeight <= 0) {
            return null;
        }
        float scaleX = (float) screenshot.getWidth() / overlayWidth;
        float scaleY = (float) screenshot.getHeight() / overlayHeight;
        Rect crop = new Rect(
                (int) Math.floor(selection.left * scaleX),
                (int) Math.floor(selection.top * scaleY),
                (int) Math.ceil(selection.right * scaleX),
                (int) Math.ceil(selection.bottom * scaleY));
        crop.intersect(0, 0, screenshot.getWidth(), screenshot.getHeight());
        if (crop.width() <= 0 || crop.height() <= 0) {
            return null;
        }
        return Bitmap.createBitmap(screenshot, crop.left, crop.top, crop.width(), crop.height());
    }

    private void recognizeSelectedArea(Bitmap bitmap) {
        Toast.makeText(context, "OCR sedang membaca...", Toast.LENGTH_SHORT).show();
        ocr.recognize(bitmap, new OcrManager.Callback() {
            @Override
            public void onText(String text) {
                recycle(bitmap);
                screenCapture.stop();
                if (text == null || text.trim().isEmpty()) {
                    Toast.makeText(context, "OCR: teks tidak ditemukan", Toast.LENGTH_SHORT).show();
                    return;
                }
                tts.speak(text);
            }

            @Override
            public void onError(Exception error) {
                recycle(bitmap);
                screenCapture.stop();
                Toast.makeText(context, "OCR error: " + errorMessage(error), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void closeSelection() {
        selectionMode = false;
        if (readingAreaView != null) {
            try {
                windowManager.removeView(readingAreaView);
            } catch (Exception ignored) {
                // The system may already have removed this overlay.
            }
            readingAreaView = null;
        }
    }

    private String errorMessage(Exception error) {
        if (error == null || error.getMessage() == null || error.getMessage().trim().isEmpty()) {
            return error == null ? "unknown" : error.getClass().getSimpleName();
        }
        return error.getMessage();
    }

    private void recycle(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            bitmap.recycle();
        }
    }

    private void vibrate() {
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vibrator.vibrate(80);
        }
    }

    public void close() {
        closed = true;
        closeSelection();
        screenCapture.close();
        tts.close();
        ocr.close();
    }
}

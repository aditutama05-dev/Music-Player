package com.example.bacachat;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

/** Keeps OCR text until the asynchronous TTS engine is ready. */
public class TtsManager {
    private final AudioManager audioManager;
    private final AudioManager.OnAudioFocusChangeListener focusChangeListener = focusChange -> {
        if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            hasAudioFocus = false;
        }
    };

    private TextToSpeech textToSpeech;
    private AudioFocusRequest audioFocusRequest;
    private boolean ready;
    private boolean hasAudioFocus;
    private String pendingText;

    public TtsManager(Context context) {
        Context appContext = context.getApplicationContext();
        audioManager = (AudioManager) appContext.getSystemService(Context.AUDIO_SERVICE);
        textToSpeech = new TextToSpeech(appContext, status -> {
            if (status != TextToSpeech.SUCCESS || textToSpeech == null) {
                return;
            }
            Locale indonesian = new Locale("id", "ID");
            int languageResult = textToSpeech.setLanguage(indonesian);
            if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Indonesian voice data is optional. Use the system default rather
                // than dropping the recognized text when it is absent.
                languageResult = textToSpeech.setLanguage(Locale.getDefault());
            }
            ready = languageResult != TextToSpeech.LANG_MISSING_DATA
                    && languageResult != TextToSpeech.LANG_NOT_SUPPORTED;
            if (ready && pendingText != null) {
                String text = pendingText;
                pendingText = null;
                speakNow(text);
            }
        });
    }

    public void speak(String text) {
        if (text == null || text.trim().isEmpty()) {
            return;
        }
        if (!ready || textToSpeech == null) {
            pendingText = text.trim();
            return;
        }
        speakNow(text);
    }

    private void speakNow(String text) {
        requestAudioFocus();
        if (textToSpeech != null) {
            textToSpeech.speak(text.trim(), TextToSpeech.QUEUE_FLUSH, null, "selection_reading");
        }
    }

    private void requestAudioFocus() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build();
            audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(attributes)
                    .setOnAudioFocusChangeListener(focusChangeListener)
                    .build();
            hasAudioFocus = audioManager.requestAudioFocus(audioFocusRequest)
                    == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        } else {
            hasAudioFocus = audioManager.requestAudioFocus(focusChangeListener, AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }
    }

    public void close() {
        pendingText = null;
        ready = false;
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        if (audioManager != null && hasAudioFocus) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
            } else {
                audioManager.abandonAudioFocus(focusChangeListener);
            }
        }
        hasAudioFocus = false;
    }
}

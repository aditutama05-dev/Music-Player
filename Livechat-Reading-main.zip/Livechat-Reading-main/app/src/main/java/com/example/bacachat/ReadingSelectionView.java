package com.example.bacachat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

public class ReadingSelectionView extends View {

    public interface SelectionListener {
        void onSelectionFinished(RectF area);
        void onSelectionCancelled();
    }

    private final Paint fillPaint =
            new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Paint borderPaint =
            new Paint(Paint.ANTI_ALIAS_FLAG);

    private final RectF selection =
            new RectF();

    private SelectionListener listener;

    private float startX;
    private float startY;

    private boolean selecting = false;

    private int dp(float value) {
        return (int) (
                value *
                getResources()
                        .getDisplayMetrics()
                        .density
        );
    }

    public ReadingSelectionView(Context context) {
        super(context);

        setBackgroundColor(
                Color.TRANSPARENT
        );

        fillPaint.setStyle(
                Paint.Style.FILL
        );

        fillPaint.setColor(
                Color.argb(
                        35,
                        80,
                        255,
                        100
                )
        );

        borderPaint.setStyle(
                Paint.Style.STROKE
        );

        borderPaint.setStrokeWidth(
                dp(3)
        );

        borderPaint.setColor(
                Color.rgb(
                        70,
                        255,
                        100
                )
        );

        setLayerType(
                View.LAYER_TYPE_SOFTWARE,
                null
        );
    }

    public void setSelectionListener(
            SelectionListener listener
    ) {
        this.listener = listener;
    }

    @Override
    protected void onDraw(Canvas canvas) {

        super.onDraw(canvas);

        if (!selecting &&
                selection.isEmpty()) {
            return;
        }

        if (!selection.isEmpty()) {

            canvas.drawRect(
                    selection,
                    fillPaint
            );

            canvas.drawRect(
                    selection,
                    borderPaint
            );
        }
    }

    @Override
    public boolean onTouchEvent(
            MotionEvent event
    ) {

        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:

                startX =
                        event.getX();

                startY =
                        event.getY();

                selection.set(
                        startX,
                        startY,
                        startX,
                        startY
                );

                selecting = true;

                invalidate();

                return true;

            case MotionEvent.ACTION_MOVE:

                if (!selecting) {
                    return true;
                }

                float currentX =
                        event.getX();

                float currentY =
                        event.getY();

                selection.set(
                        Math.min(
                                startX,
                                currentX
                        ),
                        Math.min(
                                startY,
                                currentY
                        ),
                        Math.max(
                                startX,
                                currentX
                        ),
                        Math.max(
                                startY,
                                currentY
                        )
                );

                invalidate();

                return true;

            case MotionEvent.ACTION_UP:

                if (!selecting) {
                    return true;
                }

                selecting = false;

                float width =
                        selection.width();

                float height =
                        selection.height();

                if (width < dp(40) ||
                        height < dp(30)) {

                    selection.setEmpty();

                    invalidate();

                    if (listener != null) {
                        listener.onSelectionCancelled();
                    }

                    return true;
                }

                invalidate();

                if (listener != null) {

                    listener.onSelectionFinished(
                            new RectF(selection)
                    );
                }

                return true;

            case MotionEvent.ACTION_CANCEL:

                selecting = false;

                selection.setEmpty();

                invalidate();

                if (listener != null) {
                    listener.onSelectionCancelled();
                }

                return true;
        }

        return true;
    }

    public RectF getSelection() {

        if (selection.isEmpty()) {
            return new RectF();
        }

        return new RectF(selection);
    }

    public void clearSelection() {

        selecting = false;

        selection.setEmpty();

        invalidate();
    }
                  }

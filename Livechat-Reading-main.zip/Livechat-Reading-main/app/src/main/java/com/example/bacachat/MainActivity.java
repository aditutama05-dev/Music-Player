package com.example.bacachat;

import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_OVERLAY = 100;
    private static final int REQUEST_SCREEN_CAPTURE = 101;

    private static final String PREFS_NAME =
            "live_chat_reader_prefs";

    private static final String KEY_FLOATING_ACTIVE =
            "floating_active";

    private View btnStartOverlay;

    private TextView tvStartTitle;

    private MediaProjectionManager projectionManager;

    private boolean floatingActive = false;

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    ) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_main
        );

        btnStartOverlay =
                findViewById(
                        R.id.btnStartOverlay
                );

        tvStartTitle =
                findViewById(
                        R.id.tvTitle
                );

        projectionManager =
                (MediaProjectionManager)
                        getSystemService(
                                MEDIA_PROJECTION_SERVICE
                        );

        /*
         * Status tampilan Activity tidak digunakan
         * sebagai sumber kebenaran MediaProjection.
         *
         * Saat Activity dibuka ulang, tampilkan status
         * awal saja. Service-lah yang memegang sesi capture.
         */
        floatingActive = false;

        updateActivationButton(false);

        if (btnStartOverlay != null) {

            btnStartOverlay.setOnClickListener(
                    v -> toggleFloatingButton()
            );
        }
    }

    private void toggleFloatingButton() {

        if (floatingActive) {

            stopFloatingButton();

        } else {

            startFloatingButton();
        }
    }

    private void startFloatingButton() {

        if (
                Build.VERSION.SDK_INT >=
                        Build.VERSION_CODES.M &&
                !Settings.canDrawOverlays(this)
        ) {

            Intent overlayIntent =
                    new Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse(
                                    "package:" +
                                            getPackageName()
                            )
                    );

            startActivityForResult(
                    overlayIntent,
                    REQUEST_OVERLAY
            );

            return;
        }

        requestScreenCapture();
    }

    private void requestScreenCapture() {

        if (projectionManager == null) {

            Toast.makeText(
                    this,
                    "Screen Capture tidak tersedia",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        /*
         * Selalu minta izin Screen Capture ketika
         * sesi Floating Reader baru dimulai.
         */
        Intent captureIntent =
                projectionManager
                        .createScreenCaptureIntent();

        startActivityForResult(
                captureIntent,
                REQUEST_SCREEN_CAPTURE
        );
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (
                requestCode ==
                        REQUEST_OVERLAY
        ) {

            if (
                    Build.VERSION.SDK_INT < 23 ||
                    Settings.canDrawOverlays(this)
            ) {

                requestScreenCapture();

            } else {

                Toast.makeText(
                        this,
                        "Izin tampil di atas aplikasi diperlukan",
                        Toast.LENGTH_SHORT
                ).show();
            }

            return;
        }

        if (
                requestCode ==
                        REQUEST_SCREEN_CAPTURE
        ) {

            if (
                    resultCode != RESULT_OK ||
                    data == null
            ) {

                floatingActive = false;

                updateActivationButton(false);

                Toast.makeText(
                        this,
                        "Izin tangkap layar dibatalkan",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            /*
             * Jangan lagi menyimpan MediaProjection
             * sebagai session static.
             *
             * Hasil izin langsung diberikan kepada
             * FloatingService. Service akan membuat
             * MediaProjection dan memegangnya selama
             * Floating Reader aktif.
             */
            startFloatingService(
                    resultCode,
                    data
            );
        }
    }

    private void startFloatingService(
            int resultCode,
            Intent captureData
    ) {

        if (
                resultCode != RESULT_OK ||
                captureData == null
        ) {

            floatingActive = false;

            updateActivationButton(false);

            Toast.makeText(
                    this,
                    "Data Screen Capture tidak valid",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Intent serviceIntent =
                new Intent(
                        this,
                        FloatingService.class
                );

        serviceIntent.putExtra(
                FloatingService.EXTRA_SCREEN_CAPTURE_RESULT,
                resultCode
        );

        serviceIntent.putExtra(
                FloatingService.EXTRA_SCREEN_CAPTURE_DATA,
                captureData
        );

        try {

            if (
                    Build.VERSION.SDK_INT >=
                            Build.VERSION_CODES.O
            ) {

                ContextCompat.startForegroundService(
                        this,
                        serviceIntent
                );

            } else {

                startService(
                        serviceIntent
                );
            }

            floatingActive = true;

            updateActivationButton(true);

            Toast.makeText(
                    this,
                    "Floating Button aktif",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception error) {

            floatingActive = false;

            updateActivationButton(false);

            Toast.makeText(
                    this,
                    "Gagal menjalankan Floating Service: " +
                            error.getClass()
                                    .getSimpleName(),
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void stopFloatingButton() {

        Intent serviceIntent =
                new Intent(
                        this,
                        FloatingService.class
                );

        stopService(
                serviceIntent
        );

        floatingActive = false;

        updateActivationButton(false);

        Toast.makeText(
                this,
                "Floating Button dimatikan",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void updateActivationButton(
            boolean active
    ) {

        if (tvStartTitle == null) {
            return;
        }

        if (active) {

            tvStartTitle.setText(
                    "Live Chat Reader — Aktif"
            );

        } else {

            tvStartTitle.setText(
                    "Live Chat Reader"
            );
        }
    }
            }

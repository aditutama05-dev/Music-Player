package com.example.bacachat;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;

import java.nio.ByteBuffer;

public class ScreenCaptureManager {

    public interface Callback {

        void onFrame(Bitmap bitmap);

        void onError(Exception error);
    }

    private final Context context;

    private MediaProjection mediaProjection;

    private VirtualDisplay virtualDisplay;

    private ImageReader imageReader;

    private Callback callback;

    private int screenWidth;

    private int screenHeight;

    private int screenDensity;

    private boolean frameDelivered = false;

    private final Handler mainHandler =
            new Handler(
                    Looper.getMainLooper()
            );

    private MediaProjection.Callback projectionCallback;

    public ScreenCaptureManager(
            Context context
    ) {

        this.context =
                context.getApplicationContext();

        updateScreenMetrics();
    }

    private void updateScreenMetrics() {

        DisplayMetrics metrics =
                context.getResources()
                        .getDisplayMetrics();

        screenWidth =
                metrics.widthPixels;

        screenHeight =
                metrics.heightPixels;

        screenDensity =
                metrics.densityDpi;
    }

    public void setMediaProjection(
            MediaProjection projection
    ) {

        if (
                mediaProjection ==
                        projection
        ) {

            return;
        }

        if (mediaProjection != null) {

            try {

                if (projectionCallback != null) {

                    mediaProjection.unregisterCallback(
                            projectionCallback
                    );
                }

            } catch (Exception ignored) {
            }

            try {
                mediaProjection.stop();
            } catch (Exception ignored) {
            }
        }

        mediaProjection =
                projection;

        if (mediaProjection != null) {

            registerProjectionCallback();
        }
    }

    private void registerProjectionCallback() {

        if (mediaProjection == null) {
            return;
        }

        projectionCallback =
                new MediaProjection.Callback() {

                    @Override
                    public void onStop() {

                        mainHandler.post(
                                () -> {

                                    releaseDisplayOnly();

                                    mediaProjection =
                                            null;

                                    if (callback != null) {

                                        callback.onError(
                                                new IllegalStateException(
                                                        "MediaProjection dihentikan"
                                                )
                                        );
                                    }
                                }
                        );
                    }
                };

        try {

            mediaProjection.registerCallback(
                    projectionCallback,
                    mainHandler
            );

        } catch (Exception error) {

            projectionCallback = null;
        }
    }

    public boolean isReady() {

        return mediaProjection != null;
    }

    public void start(
            Callback callback
    ) {

        stop();

        this.callback =
                callback;

        frameDelivered = false;

        if (mediaProjection == null) {

            notifyError(
                    new IllegalStateException(
                            "MediaProjection belum tersedia"
                    )
            );

            return;
        }

        updateScreenMetrics();

        try {

            imageReader =
                    ImageReader.newInstance(
                            screenWidth,
                            screenHeight,
                            PixelFormat.RGBA_8888,
                            2
                    );

            imageReader.setOnImageAvailableListener(
                    reader -> {

                        Image image = null;

                        try {

                            image =
                                    reader.acquireLatestImage();

                            if (image == null) {
                                return;
                            }

                            if (frameDelivered) {
                                return;
                            }

                            Bitmap bitmap =
                                    imageToBitmap(
                                            image
                                    );

                            if (
                                    bitmap != null &&
                                    this.callback != null
                            ) {

                                frameDelivered = true;

                                Callback currentCallback =
                                        this.callback;

                                this.callback = null;

                                currentCallback.onFrame(
                                        bitmap
                                );
                            }

                        } catch (Exception error) {

                            notifyError(error);

                        } finally {

                            if (image != null) {
                                image.close();
                            }
                        }

                    },
                    mainHandler
            );

            virtualDisplay =
                    mediaProjection.createVirtualDisplay(
                            "LiveChatReader",
                            screenWidth,
                            screenHeight,
                            screenDensity,
                            DisplayManager
                                    .VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                            imageReader.getSurface(),
                            null,
                            mainHandler
                    );

            if (virtualDisplay == null) {

                notifyError(
                        new IllegalStateException(
                                "VirtualDisplay gagal dibuat"
                        )
                );
            }

        } catch (Exception error) {

            notifyError(error);
        }
    }

    private Bitmap imageToBitmap(
            Image image
    ) {

        Image.Plane[] planes =
                image.getPlanes();

        if (
                planes == null ||
                planes.length == 0
        ) {

            return null;
        }

        Image.Plane plane =
                planes[0];

        ByteBuffer buffer =
                plane.getBuffer();

        int pixelStride =
                plane.getPixelStride();

        int rowStride =
                plane.getRowStride();

        if (
                pixelStride <= 0 ||
                rowStride <= 0
        ) {

            return null;
        }

        int rowPadding =
                rowStride -
                        pixelStride *
                                screenWidth;

        int bitmapWidth =
                screenWidth +
                        rowPadding /
                                pixelStride;

        Bitmap bitmap =
                Bitmap.createBitmap(
                        bitmapWidth,
                        screenHeight,
                        Bitmap.Config.ARGB_8888
                );

        buffer.rewind();

        bitmap.copyPixelsFromBuffer(
                buffer
        );

        if (
                bitmapWidth !=
                        screenWidth
        ) {

            Bitmap cropped =
                    Bitmap.createBitmap(
                            bitmap,
                            0,
                            0,
                            screenWidth,
                            screenHeight
                    );

            bitmap.recycle();

            return cropped;
        }

        return bitmap;
    }

    private void notifyError(
            Exception error
    ) {

        Callback currentCallback =
                callback;

        callback = null;

        if (currentCallback != null) {

            currentCallback.onError(
                    error
            );
        }
    }

    /*
     * Hanya menghentikan VirtualDisplay dan
     * ImageReader.
     *
     * MediaProjection tetap hidup supaya
     * pembacaan berikutnya bisa dilakukan.
     */
    public void stop() {

        releaseDisplayOnly();

        callback = null;

        frameDelivered = false;
    }

    private void releaseDisplayOnly() {

        if (virtualDisplay != null) {

            try {
                virtualDisplay.release();
            } catch (Exception ignored) {
            }

            virtualDisplay = null;
        }

        if (imageReader != null) {

            try {
                imageReader.close();
            } catch (Exception ignored) {
            }

            imageReader = null;
        }
    }

    /*
     * Dipanggil ketika FloatingService benar-benar
     * dimatikan.
     */
    public void close() {

        releaseDisplayOnly();

        callback = null;

        frameDelivered = false;

        if (mediaProjection != null) {

            try {

                if (projectionCallback != null) {

                    mediaProjection.unregisterCallback(
                            projectionCallback
                    );
                }

            } catch (Exception ignored) {
            }

            try {
                mediaProjection.stop();
            } catch (Exception ignored) {
            }

            mediaProjection = null;
        }

        projectionCallback = null;
    }
                    }
